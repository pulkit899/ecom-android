package com.example.ecom_android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class video_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_video_page);
    }
}